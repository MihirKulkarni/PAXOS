************************************README************************************

Project for EECS 218- PAXOS Implementation and Tester, Prof. Demsky


PROJECT TITLE:
	PAXOS Implementation and Tester


TEAM:
	Member-1
	Name : Karthik Ragunath Balasundaram
	Student ID : 78806170
	UCI Student ID : kbalasun

	Member-2
	Name : Mihir Kulkarni
	Student ID : 89481531
	UCI Student ID : mihirk


STEPS TO RUN PROJECT:
	1. untar the tar ball which would create the directories PAXOS/ and Test/.

	2. Compile it by running the following commands,
                javac PAXOS/*.java
                javac Test/*.java

	3. Run the Tester by running the command,
                java Test.Test

	4. The terminate_run() method of the TestNetwork object terminates the current run. printTrace() method of the TestNetwork object prints the Message Trace in case of a Broken PAXOS.
  
MORE INFORMATION:
	Please refer to the source code file for comments to help understand the code.
