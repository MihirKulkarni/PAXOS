package Test;
import Paxos.*;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Date;

public class TestChannel extends Channel {
  TestNetwork test_network;
  int test_index=-1;
  int terminate=0;//set to 1 to terminate;
  int block_channel=0; //set to 1 to block messages
  int DP_mode=-1; //0->single DP, 1-> All DP, 2-> Cycle DP, 3->make specific proposer as DP
  int requested_DP=-1; // process ID for DP_mode=3
  int lose_msg=0; //0->normal operation 1->lose all message in queue
  int dup_msg = 0; //0->normal operation 1->wait and duplicate message 2->send multiple copies
  int reorder_msg=0; //0-> normal operation using FIFO queues 1-> reorder message using LIFO stack 
  int init_logic=0;  //0->test_index 1->(-)test_index 2->decremental test_index(-5) 3->multiplicative test_index(*5) 4->decremental from MAX_INT 5->incremental from MIN_INT
  /* Send the message message to process destination. */


  public void sendMessage(int destination, String message) {
    throw_exception();
    if(reorder_msg==0){
      synchronized(test_network.test_queues[destination]) {
        if(dup_msg==0){
          update_MessageTrace(" Send -> "+message);
          test_network.test_queues[destination].add(message);
        }
        if(dup_msg == 1){
          try{
            Thread.sleep(200);
            for(int i = 3; i>0; i--){
              update_MessageTrace(" Send -> "+message);
              test_network.test_queues[destination].add(message);
            }
          }catch (Exception e){} 
        }   
        if(dup_msg == 2){
          for(int i = 3; i>0; i--){
            update_MessageTrace(" Send -> "+message);
            test_network.test_queues[destination].add(message);
          } 
        }   
      }
    }  
    if(reorder_msg==1){
      synchronized(test_network.test_stacks[destination]) {
        if(dup_msg==0){
          update_MessageTrace(" Send -> "+message);
          test_network.test_stacks[destination].push(message);
        }
        if(dup_msg == 1){
          try{
            Thread.sleep(200);
            for(int i = 3; i>0; i--){
              update_MessageTrace(" Send -> "+message);
              test_network.test_stacks[destination].push(message);
            }
          }catch (Exception e){} 
        }   
        if(dup_msg == 2){
          for(int i = 3; i>0; i--){
            update_MessageTrace(" Send -> "+message);
            test_network.test_stacks[destination].push(message);
          }
        }   
      }
    }

  }

  /** Receive a message. */

  public String receiveMessage() {
    throw_exception();
    if(block_channel==1){
      return null;
    }
    if(reorder_msg==0){
      synchronized(test_network.test_queues[test_index]) {
        if(lose_msg==1){
          while(!test_network.test_queues[test_index].isEmpty())
            test_network.test_queues[test_index].remove();
        }
        else{    
          if (!test_network.test_queues[test_index].isEmpty()){
            String msg=test_network.test_queues[test_index].remove();
            update_MessageTrace(" Recv <- "+msg);
            return msg;
          }
          else
            return null;
        }
      }
    }

    if(reorder_msg==1){
      synchronized(test_network.test_stacks[test_index]) {
        if(lose_msg==1){
          while(!test_network.test_stacks[test_index].isEmpty())
            test_network.test_stacks[test_index].pop();
        }
        else{    
          if (!test_network.test_stacks[test_index].isEmpty()){
            String msg=test_network.test_stacks[test_index].pop();
            update_MessageTrace(" Recv <- "+msg);
            return msg;
          }
          else
            return null;
        }
      }
    }
    return null;
  }

  /** Call this function to determine whether a proposer is distinguished. */

  public boolean isDistinguished(){
    throw_exception();

    while(DP_mode==-1){}
    if(DP_mode==0){  
      if (test_index==0)
        return true;
    }
    if(DP_mode==1){  
      if (test_index<test_network.test_numProposers)
        return true;
    }
    if(DP_mode==2){  
      Date d=new Date();
      long cur_time=d.getTime();
      if ((cur_time/1000)%test_network.test_numProposers==test_index) {
        return true;
      } 
    }
    if(DP_mode==3){
      if (test_index==requested_DP)
        return true;
    }
 
    if (test_index>=test_network.test_numProposers)
      throw new Error("Non-proposers should not be asking whether they are distinguished");
    return false;

  }

  /** Call this function to register a decision by a learner. */

  public void decide(int decision) {
    if (test_index<(test_network.test_numProposers+test_network.test_numAcceptors))
      throw new Error("Non-learner should not be deciding a value");
    if(init_logic==0) 
      if (decision>=test_network.test_numProposers && decision<0){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   
    if(init_logic==1) 
      if (decision<=test_network.test_numProposers*(-1) && decision>0){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   
    if(init_logic==2) 
      if (decision>=test_network.test_numProposers-5 && decision<-5){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   
    if(init_logic==3) 
      if ((decision%5)>=test_network.test_numProposers){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   
    if(init_logic==4) 
      if (decision<=Integer.MAX_VALUE-test_network.test_numProposers){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   
    if(init_logic==5) 
      if (decision>=Integer.MIN_VALUE+test_network.test_numProposers){
        test_network.error_flag=1; 
        throw new Error("The decided value was not an initial value...PAXOS BROKEN!!! :)");
      }   

    synchronized(test_network) {
      if (test_network.test_decision==-1)
        test_network.test_decision=decision;
      else {
        if (test_network.test_decision!=decision){
          System.out.println("Disagreement between Learners. PAXOS BROKEN!!! :)");
          test_network.error_flag=1; 
        }
      }
    }
    throw_exception();
  }
  /** Call this function to get the initial value for a proposer. */

  public int getInitialValue() {
    throw_exception();
    if (test_index>=test_network.test_numProposers)
      throw new Error("Non-proposers should not be asking for initial value");
    if(init_logic==1)
      return test_index*(-1);
    if(init_logic==2)
      return test_index-5;
    if(init_logic==3)
      return test_index*5;
    if(init_logic==4)
      return Integer.MAX_VALUE-test_index;
    if(init_logic==5)
      return Integer.MIN_VALUE+test_index;
    return test_index;
  }
  
  public void shuffle_msg(){
    throw_exception();
    if(reorder_msg==0)
      Collections.shuffle(test_network.test_queues[test_index]); 
    if(reorder_msg==1)
      Collections.shuffle(test_network.test_stacks[test_index]); 
  }
  
  public void throw_exception(){
    StopError s=new StopError();  
    if(terminate==1)
      s.throw_error();
  }
  public void sleep() {
    try{
      Thread.sleep(0);
    } 
    catch (InterruptedException e) {
      System.out.println("Interrupted");
    }
  }

  public String getCurTime(){
    Date d = new Date ();
    String date_str="";
    if(d.getHours()<10)
      date_str="0";
    date_str+=d.getHours()+":";
    if(d.getMinutes()<10)
      date_str+="0";
    date_str+=d.getMinutes()+":";
    if(d.getSeconds()<10)
      date_str+="0";
    date_str+=d.getSeconds()+":";
    int n = (int) d.getTime() % 1000;
    date_str+=(n<0 ? n+1000 : n);
    return date_str; 
  }
  public void update_MessageTrace(String msg){
    if(reorder_msg==0 || reorder_msg==1){
      synchronized(test_network.MessageTrace){
        String whoamI=""; 
        if(test_index<test_network.numProposers())
          whoamI="Proposer - "+test_index;
        if(test_index>=test_network.numProposers() && test_index<test_network.numAcceptors()+test_network.numProposers())
          whoamI="Acceptor - "+test_index;
        if(test_index>=test_network.numAcceptors()+test_network.numProposers() && test_index<test_network.test_totalProcesses)
          whoamI="Learner  - "+test_index;
        test_network.MessageTrace.add(getCurTime()+" "+whoamI+msg);
      }
    }
  }
}
